# Medical Chart Review

Portable static chart-review prototype. This export includes only the entirely fictional Alex Morgan starter case. Patient-derived packet files, summaries, prior Git history and Sites configuration are excluded. No live-record upload, OCR, app-owned authentication, server persistence, or AI processing is implemented. Sites adds platform-level access controls; these are not portable app authentication.

## Nine clinical-note templates

The **Note templates (9)** button opens the structured-note workspace. Supported templates: hospital/office consultation, admission H&P, hospital progress, office progress, ICU admission/consultation/transfer, ICU daily progress, ED physician, physical therapy, and speech-language pathology. Known consultation/admission/ED/office report entries also have **Open in note template**. Legacy report content is explicitly labeled an indexed summary, never a complete source extraction.

Paste extracted text for one identified encounter, using `[[PAGE 10]]` and subsequent page markers to preserve original PDF page numbers. Select the template and organize the text. Exact recognized headings map to fields. Ambiguous or unknown content remains in **Needs placement**. This deterministic heading parser does not synthesize clinical information, split unrelated encounters automatically, extract scans, or call a model. Realistic OCR and semantic extraction require a future backend integration.

Each field retains original text and its page/line evidence. Reviewers may correct text, mark it reviewed, place unassigned text, or confirm a missing/nonapplicable field. Empty fields initially say **Not extracted — check source**, because extraction failure does not prove the original lacks information. Attending attestations/addenda remain separate from the original note and retain distinct author/timestamp metadata. Existing provider statements are not replaced.

PT and SLP tables display aligned pipe-separated source tables where available; otherwise the original text remains editable alongside expected columns. No measurements, scores, billing units, treatment completion, or clinical conclusions are inferred.

Attach a synthetic/properly deidentified PDF solely for browser-local source viewing. Nothing is uploaded to a server. Workspace state is held in memory, with **Export reviewed work** and **Import saved work** to preserve/reload JSON. Exports include source text, original extraction, edits, references, and authors/addenda; PDFs must be kept and reattached separately. Export is not cloud persistence. Unorganized edits to input are exported separately as `pendingSourceText` so existing source references stay intact.

## Read PDF (page-by-page text)

The **Read PDF** button opens a PDF and pulls out its text one page at a time. Everything happens in the browser: the file is never uploaded, and PDF.js is hosted inside this repository (`vendor/pdfjs`), so no outside servers are contacted.

- Each page shows its text in reading order, with table columns lined up.
- Each page gets a status: **Text found**, **Very little text**, or **No text layer — likely scanned; needs OCR**. Scanned pages are flagged and never guessed.
- Choose pages (for example `7-10, 12`), then **Copy text**, **Download .txt**, or **Download .json**. Text keeps the original page numbers with `[[PAGE n]]` markers.
- **Send to note templates** puts the selected pages into the note workspace and attaches the PDF for verification.
- Password-protected PDFs must be unlocked first. OCR for scanned pages is not yet included.

Files: `pdf-text-core.js` (line rebuilding and page status, no DOM), `pdf-reader.js` / `.css` (interface), `vendor/pdfjs/` (PDF.js 5.7.284, Apache-2.0), `staticwebapp.config.json` (serves `.mjs` files correctly on Azure). Run `node pdf-reader.test.mjs` to check extraction against `synthetic-records.pdf`.

## Portable implementation

- `note-templates.js`: nine host-independent section/field definitions and table columns.
- `note-engine.js`: deterministic extraction, validation, shared extraction safeguards, provider-neutral contract export.
- `note-workspace.js` / `.css`: template selection, review/editor, original evidence, separate authors/addenda, source viewing, JSON import/export.
- `data.js`, `lab-catalog.js`, `app.js`: existing chart navigation and fixtures.

All files live at the repository root (no build step or `dist/` folder — this matches how the Azure Static Web Apps workflow deploys the site directly from `/`). No installation or build is required. The note engine also works in Node via CommonJS. Run `node note-engine.test.cjs` to verify schema coverage and core source-fidelity safeguards. No browser QA has been run for this change.

Future Azure/AI integration should return structured output that passes the note validator and must validate evidence against original OCR page/line content; the current validator only checks structure. The exported extraction specification supplies the target fields and instructions, not executable AI credentials or a production endpoint. Production also requires encounter segmentation, secure persistence, appropriate account controls, end-to-end evidence validation, and evaluation on representative records.

## Run locally

With Python installed, run from this folder:

```sh
python -m http.server 8000
```

Open http://localhost:8000. Any static host can serve the contents of this folder.
No Azure connection or portable login protection is included.

## Upload to GitHub

Repository: https://github.com/shokrisy4520/Medical-Chart-Review-.git

Extract the archive first. On the empty GitHub repository page, choose
“uploading an existing file”, then drag the extracted folder's contents
into the upload area and commit to main. Do not upload the ZIP itself
as the source code.

Alternatively, from this extracted folder with Git installed and authenticated:

```sh
git init -b main
git add .
git commit -m "Import portable nine-template prototype"
git remote add origin https://github.com/shokrisy4520/Medical-Chart-Review-.git
git push -u origin main
```

This is a fresh export: do not push the original Sites Git history, which contains excluded case material.
Keep the repository private. Review any future case data before committing.
