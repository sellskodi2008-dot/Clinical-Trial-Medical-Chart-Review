/*
 * pdf-reader.js — "Read PDF" tool.
 * Opens a PDF in the browser, pulls out the embedded text page by page,
 * flags pages that have no text layer (likely scans), and lets the reviewer
 * copy, download, or send selected pages to the note-template workspace.
 *
 * Privacy: the PDF is read with the File API and parsed by a locally hosted
 * copy of PDF.js (vendor/pdfjs). Nothing is uploaded or sent to any server.
 */
import * as pdfjsLib from './vendor/pdfjs/pdf.min.mjs';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdfjs/pdf.worker.min.mjs', import.meta.url).href;

const Core = window.PdfTextCore;
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const state = { file: null, doc: null, pages: [], cancel: false, running: false };

const dialog = document.createElement('dialog');
dialog.id = 'pdfReader';
dialog.setAttribute('aria-labelledby', 'prTitle');
dialog.innerHTML = `
<div class="pr-header">
  <div><h2 id="prTitle">Read PDF</h2><p>Pull out the text page by page · Processed only in this browser</p></div>
  <button id="prClose" aria-label="Close PDF reader">Close</button>
</div>
<div class="pr-toolbar">
  <label class="pr-file">Choose a PDF<input id="prFile" type="file" accept="application/pdf,.pdf"></label>
  <div class="pr-drop" id="prDrop">or drop a PDF here</div>
  <div class="pr-summary" id="prSummary" role="status" aria-live="polite">No PDF loaded.</div>
  <button id="prCancel" hidden>Stop</button>
</div>
<div class="pr-progress" hidden id="prProgressWrap"><div id="prProgress"></div></div>
<p class="pr-notice">Reads the text already stored inside the PDF. Scanned pages (pictures of paper) have no stored text and are flagged for OCR — they are never guessed. Use synthetic or properly deidentified records until use with patient data is approved.</p>
<div class="pr-actions" id="prActions" hidden>
  <label>Pages <input id="prRange" placeholder="All, or e.g. 7-10, 12" size="18"></label>
  <label class="pr-inline"><input type="checkbox" id="prOnlyIssues"> Show only pages needing attention</label>
  <span class="pr-spacer"></span>
  <button id="prCopy">Copy text</button>
  <button id="prTxt">Download .txt</button>
  <button id="prJson">Download .json</button>
  <button id="prSend" class="pr-primary">Send to note templates</button>
</div>
<div class="pr-body" id="prBody"><div class="pr-empty">Choose a PDF to begin.</div></div>`;
document.body.append(dialog);

const launcher = document.createElement('button');
launcher.id = 'pdfReaderOpen';
launcher.textContent = 'Read PDF';
$('reset').before(launcher);
launcher.onclick = () => dialog.showModal();
$('prClose').onclick = () => dialog.close();

function summary(text) { $('prSummary').textContent = text; }

function counts() {
  const c = { ok: 0, sparse: 0, 'no-text': 0 };
  state.pages.forEach(p => c[p.status.code]++);
  return c;
}

function selectedPages() {
  const nums = Core.parseRange($('prRange').value, state.doc ? state.doc.numPages : 0);
  const byNum = new Map(state.pages.map(p => [p.page, p]));
  return nums.map(n => byNum.get(n)).filter(Boolean);
}

function renderPage(p) {
  const cls = p.status.code;
  return `<article class="pr-page pr-${cls}" id="pr-page-${p.page}">
    <header><h3>Page ${p.page}</h3><span class="pr-badge">${esc(p.status.label)}</span>
      <small>${p.status.chars.toLocaleString()} characters · ${p.lineCount} lines</small>
      <button data-copy="${p.page}">Copy page</button></header>
    ${p.text ? `<pre tabindex="0">${esc(p.text)}</pre>` : '<p class="pr-none">No text could be read from this page.</p>'}
  </article>`;
}

function render() {
  const only = $('prOnlyIssues').checked;
  const list = state.pages.filter(p => !only || p.status.code !== 'ok');
  $('prBody').innerHTML = list.length ? list.map(renderPage).join('') :
    `<div class="pr-empty">${only ? 'Every page has readable text.' : 'No pages read yet.'}</div>`;
}

function finalSummary() {
  const c = counts(), total = state.doc.numPages;
  let s = `${state.file.name} · ${total} page${total === 1 ? '' : 's'} · ${c.ok} with text`;
  if (c.sparse) s += ` · ${c.sparse} with very little text`;
  if (c['no-text']) s += ` · ${c['no-text']} with no text (need OCR)`;
  summary(s);
}

async function load(file) {
  if (state.running) return;
  if (!file || !(/\.pdf$/i.test(file.name) || file.type === 'application/pdf')) { summary('That file is not a PDF.'); return; }
  if (state.doc) { try { await state.doc.destroy(); } catch (_) {} }
  Object.assign(state, { file, doc: null, pages: [], cancel: false, running: true });
  $('prActions').hidden = true; $('prRange').value = ''; $('prOnlyIssues').checked = false;
  $('prBody').innerHTML = ''; $('prCancel').hidden = false; $('prProgressWrap').hidden = false; $('prProgress').style.width = '0%';
  summary(`Opening ${file.name}…`);
  try {
    const data = new Uint8Array(await file.arrayBuffer());
    state.doc = await pdfjsLib.getDocument({ data, isEvalSupported: false }).promise;
    const total = state.doc.numPages;
    for (let n = 1; n <= total; n++) {
      if (state.cancel) break;
      const page = await state.doc.getPage(n);
      const content = await page.getTextContent();
      const rec = Core.pageRecord(n, content);
      state.pages.push(rec);
      page.cleanup();
      $('prBody').insertAdjacentHTML('beforeend', renderPage(rec));
      $('prProgress').style.width = `${Math.round((n / total) * 100)}%`;
      summary(`Reading page ${n} of ${total}…`);
    }
    if (state.cancel) summary(`Stopped after ${state.pages.length} of ${total} pages.`); else finalSummary();
    $('prActions').hidden = !state.pages.length;
  } catch (err) {
    const pw = err && err.name === 'PasswordException';
    summary(pw ? 'This PDF is password-protected. Open it with the password and save an unlocked copy first.' : `Could not read this PDF: ${err && err.message ? err.message : err}`);
  } finally {
    state.running = false; $('prCancel').hidden = true; $('prProgressWrap').hidden = true;
  }
}

function download(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = Object.assign(document.createElement('a'), { href: url, download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const baseName = () => (state.file ? state.file.name.replace(/\.pdf$/i, '') : 'pdf') + '-text';

function withSelection(fn) {
  try { const pages = selectedPages(); if (!pages.length) throw new Error('No pages selected.'); fn(pages); }
  catch (e) { summary(e.message); }
}

async function copy(text, what) {
  try { await navigator.clipboard.writeText(text); summary(`Copied ${what}.`); }
  catch (_) { summary('Copy was blocked by the browser. Use Download .txt instead.'); }
}

$('prFile').onchange = e => { load(e.target.files[0]); e.target.value = ''; };
$('prCancel').onclick = () => { state.cancel = true; };
$('prOnlyIssues').onchange = render;
$('prBody').onclick = e => {
  const b = e.target.closest('[data-copy]'); if (!b) return;
  const p = state.pages.find(x => x.page === +b.dataset.copy);
  if (p) copy(Core.withPageMarkers([p]), `page ${p.page}`);
};
$('prCopy').onclick = () => withSelection(pages => copy(Core.withPageMarkers(pages), `${pages.length} page${pages.length === 1 ? '' : 's'}`));
$('prTxt').onclick = () => withSelection(pages => download(baseName() + '.txt', Core.withPageMarkers(pages), 'text/plain'));
$('prJson').onclick = () => withSelection(pages => download(baseName() + '.json', JSON.stringify(Core.exportRecord(state.file.name, state.doc.numPages, pages), null, 2), 'application/json'));

// Hand selected pages to the existing note-template workspace, keeping
// original page numbers via [[PAGE n]] markers and attaching the source PDF.
$('prSend').onclick = () => withSelection(pages => {
  const opener = $('noteTemplates');
  if (!opener) { summary('Note templates are not available on this page.'); return; }
  const text = $('nwText'), name = $('nwSourceName');
  if (text.value.trim() && !confirm('Replace the note text that is already in the note templates workspace?')) return;
  dialog.close();
  opener.click();
  text.value = Core.withPageMarkers(pages);
  text.dispatchEvent(new Event('input', { bubbles: true }));
  if (name && !name.value.trim()) { name.value = state.file.name; name.dispatchEvent(new Event('input', { bubbles: true })); }
  try {
    const dt = new DataTransfer(); dt.items.add(state.file);
    const pdfInput = $('nwPdf'); pdfInput.files = dt.files; pdfInput.dispatchEvent(new Event('change', { bubbles: true }));
  } catch (_) { /* Older browsers: reviewer can attach the PDF manually. */ }
  text.focus();
});

const drop = $('prDrop');
['dragenter', 'dragover'].forEach(t => dialog.addEventListener(t, e => { e.preventDefault(); drop.classList.add('pr-over'); }));
['dragleave', 'drop'].forEach(t => dialog.addEventListener(t, e => { e.preventDefault(); if (t === 'drop' || e.target === dialog) drop.classList.remove('pr-over'); }));
dialog.addEventListener('drop', e => { const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) load(f); });
