/*
 * pdf-text-core.js
 * Pure, host-independent logic for turning PDF.js text items into readable
 * page text. No DOM, no network. Works in the browser (window.PdfTextCore)
 * and in Node (require / import).
 *
 * Nothing here interprets clinical meaning. It only rebuilds lines in reading
 * order and reports whether a page appears to have a usable text layer.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PdfTextCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // A page with fewer than this many non-space characters is treated as
  // "no usable text layer" (usually a scanned image). It is flagged, never guessed.
  const MIN_TEXT_CHARS = 20;

  /**
   * Rebuild lines from PDF.js textContent.items.
   * Items are grouped by baseline (y), sorted left-to-right (x), and wide
   * horizontal gaps are padded to the text's page position so table columns line up.
   */
  function buildLines(items) {
    const glyphs = [];
    for (const it of items || []) {
      if (!it || typeof it.str !== 'string' || !it.transform) continue;
      if (it.str === '' && !it.hasEOL) continue;
      const [a, b, , d, x, y] = it.transform;
      const fontSize = Math.hypot(a, b) || Math.abs(d) || 10;
      glyphs.push({ str: it.str, x, y, w: it.width || 0, size: fontSize });
    }
    if (!glyphs.length) return [];

    // Average character width on this page, used to line up table columns.
    let tw = 0, tc = 0, minX = Infinity;
    for (const g of glyphs) if (g.str.trim()) { tw += g.w; tc += g.str.length; minX = Math.min(minX, g.x); }
    const avgChar = tc && tw ? tw / tc : 5;
    const padTo = (line, x) => {
      const target = Math.round((x - minX) / avgChar);
      const base = line.replace(/\s+$/, '');
      return base + ' '.repeat(Math.max(2, target - base.length));
    };

    // Top of page first (PDF y grows upward), then left to right.
    glyphs.sort((p, q) => (q.y - p.y) || (p.x - q.x));

    const rows = [];
    for (const g of glyphs) {
      const row = rows[rows.length - 1];
      const tol = Math.max(2, g.size * 0.45);
      if (row && Math.abs(row.y - g.y) <= tol) row.parts.push(g);
      else rows.push({ y: g.y, parts: [g] });
    }

    // Insert a blank line where the vertical gap is clearly larger than normal
    // line spacing, so headings and paragraphs stay visually separated.
    const out = [];
    rows.forEach((row, i) => {
      if (i > 0) {
        const prev = rows[i - 1];
        const size = Math.max(...row.parts.map(p => p.size), ...prev.parts.map(p => p.size));
        if (prev.y - row.y > size * 1.9) out.push('');
      }
      out.push(rowText(row));
    });
    return out;

    function rowText(row) {
      row.parts.sort((p, q) => p.x - q.x);
      let line = '', end = null;
      for (const p of row.parts) {
        const charW = p.size * 0.5;
        // A whitespace item that spans a wide area is a column gap, not one space.
        if (!p.str.trim()) {
          if (p.w > charW * 2.5) { line = padTo(line, p.x + p.w); end = p.x + p.w; }
          else if (line && !/\s$/.test(line)) { line += ' '; end = p.x + p.w; }
          continue;
        }
        if (end !== null) {
          const gap = p.x - end;
          if (gap > charW * 2.5) line = padTo(line, p.x);
          else if (gap > charW * 0.25 && !/\s$/.test(line) && !/^\s/.test(p.str)) line += ' ';
        }
        line += p.str;
        end = p.x + p.w;
      }
      return line.replace(/\s+$/, '');
    }
  }

  /** Collapse runs of blank lines to one and trim the ends. */
  function tidy(lines) {
    const out = [];
    for (const l of lines) {
      if (!l.trim()) { if (out.length && out[out.length - 1] !== '') out.push(''); }
      else out.push(l);
    }
    while (out.length && out[out.length - 1] === '') out.pop();
    return out;
  }

  /** Classify a page's extracted text. */
  function pageStatus(text) {
    const chars = (text || '').replace(/\s/g, '').length;
    if (chars === 0) return { code: 'no-text', label: 'No text layer — likely scanned; needs OCR', chars };
    if (chars < MIN_TEXT_CHARS) return { code: 'sparse', label: 'Very little text — check the original page', chars };
    return { code: 'ok', label: 'Text found', chars };
  }

  /** Build a page record from PDF.js textContent. */
  function pageRecord(pageNumber, textContent) {
    const lines = tidy(buildLines(textContent && textContent.items));
    const text = lines.join('\n');
    return { page: pageNumber, text, lineCount: lines.filter(l => l.trim()).length, status: pageStatus(text) };
  }

  /**
   * Join pages using the [[PAGE n]] markers the note-template workspace
   * already understands, so page numbers from the original PDF are preserved.
   */
  function withPageMarkers(pages) {
    return pages.map(p => `[[PAGE ${p.page}]]\n${p.text || ''}`).join('\n\n');
  }

  /** Parse "1-3, 7, 10-12" into sorted unique page numbers within 1..max. */
  function parseRange(input, max) {
    const set = new Set();
    const s = String(input || '').trim();
    if (!s) { for (let i = 1; i <= max; i++) set.add(i); return [...set]; }
    for (const part of s.split(',')) {
      const m = part.trim().match(/^(\d+)\s*(?:-\s*(\d+))?$/);
      if (!m) throw new Error(`Could not read page range "${part.trim()}". Use a format like 1-3, 7.`);
      let a = +m[1], b = m[2] ? +m[2] : a;
      if (a > b) [a, b] = [b, a];
      for (let i = a; i <= b; i++) if (i >= 1 && i <= max) set.add(i);
    }
    if (!set.size) throw new Error(`No pages in that range. This PDF has ${max} pages.`);
    return [...set].sort((x, y) => x - y);
  }

  /** Portable export record: text only, no PDF bytes. */
  function exportRecord(fileName, pageCount, pages) {
    return {
      format: 'medical-chart-review/pdf-text@1',
      sourceFile: fileName,
      pageCount,
      extractedAt: new Date().toISOString(),
      method: 'PDF embedded text layer (PDF.js). No OCR. No AI. Processed locally in the browser.',
      pages: pages.map(p => ({ page: p.page, status: p.status.code, characters: p.status.chars, text: p.text }))
    };
  }

  return { MIN_TEXT_CHARS, buildLines, tidy, pageStatus, pageRecord, withPageMarkers, parseRange, exportRecord };
});
