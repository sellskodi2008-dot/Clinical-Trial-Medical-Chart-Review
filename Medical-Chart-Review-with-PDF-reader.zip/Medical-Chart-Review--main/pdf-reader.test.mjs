// Run: node pdf-reader.test.mjs
// Extracts synthetic-records.pdf page by page with the same core logic the browser uses.
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
// Node has no DOMMatrix; text extraction never uses it, so a stub is enough.
globalThis.DOMMatrix ??= class DOMMatrix {};
const pdfjsLib = await import('./vendor/pdfjs/pdf.min.mjs');
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdfjs/pdf.worker.min.mjs', import.meta.url).href;
const Core = createRequire(import.meta.url)('./pdf-text-core.js');

const data = new Uint8Array(await readFile(new URL('./synthetic-records.pdf', import.meta.url)));
const doc = await pdfjsLib.getDocument({ data, isEvalSupported: false }).promise;
const pages = [];
for (let n = 1; n <= doc.numPages; n++) pages.push(Core.pageRecord(n, await (await doc.getPage(n)).getTextContent()));

assert.equal(doc.numPages, 14, 'sample has 14 pages');
assert.ok(pages.every(p => p.status.code === 'ok'), 'every sample page has a text layer');
assert.match(pages[0].text, /White Blood Cell Count\s{2,}11\.5/, 'table columns stay on one line with spacing');
assert.match(pages[0].text, /Alex Morgan/, 'header text read');
assert.ok(pages[0].text.indexOf('Laboratory results') < pages[0].text.indexOf('Hemoglobin'), 'top-to-bottom order');

const marked = Core.withPageMarkers(pages.slice(6, 8));
assert.match(marked, /^\[\[PAGE 7\]\]\n/, 'page markers keep original page numbers');
assert.match(marked, /\n\n\[\[PAGE 8\]\]\n/);

assert.deepEqual(Core.parseRange('', 3), [1, 2, 3]);
assert.deepEqual(Core.parseRange('3-1, 7, 20', 10), [1, 2, 3, 7]);
assert.throws(() => Core.parseRange('abc', 10));
assert.equal(Core.pageStatus('').code, 'no-text');
assert.equal(Core.pageStatus('short').code, 'sparse');
assert.equal(Core.pageRecord(1, { items: [] }).status.code, 'no-text', 'blank/scanned page is flagged, not guessed');

// Pipe into the existing note engine the way "Send to note templates" does.
const NoteEngine = createRequire(import.meta.url)('./note-engine.js');
assert.ok(NoteEngine, 'note engine loads');

console.log(`PASS: ${doc.numPages} pages read; page order, column spacing, [[PAGE n]] markers, range parsing, scanned-page flagging.`);
console.log('\n--- Page 7 preview ---\n' + pages[6].text.split('\n').slice(0, 12).join('\n'));
